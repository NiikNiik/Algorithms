let arr = [1, 2, 3];
const num = 4;
index = 1;

function pushFront(arr, num ) {
    for (i = arr.length; i >= 0; i--){
        arr[i] = arr[i - 1]
    }
    arr[0] = num
    return arr
}

console.log(pushFront(arr, num));

function popFront(arr){
    let firstValue = arr[0]
    for (i = 0; i < arr.length; i++){
        arr[i] = arr[i + 1]
    }
    arr.length = arr.length -1
    console.log(arr)

    return firstValue
}

console.log(popFront(arr))

function insertAt(arr, index, num){
    for (i = arr.length; i >= index; i--){
        arr[i] = arr[i - 1]
    }
    arr[index] = num
    return arr
}

console.log(insertAt(arr,index, num))

/* function removeAt(arr, index){
    let removeEle = arr[index]
    for (i = index-1; i == arr.length; i++){
        arr[i] = arr[i + 1]
    }
    //arr.length = arr.length -1
    console.log(arr)
    return removeEle
}

console.log(arr)
console.log(removeAt(arr, index))

function swapPairs(arr){

}
*/